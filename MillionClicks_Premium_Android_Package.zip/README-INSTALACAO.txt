MILLION CLICKS PREMIUM — APP ANDROID

Este pacote é um jogo web instalável (PWA), preparado para ser publicado por HTTPS e depois empacotado como APK usando um serviço online. O pacote não é um APK pronto.

O QUE INCLUI
- index.html: jogo completo, visual escuro premium.
- manifest.webmanifest: metadados de app instalável.
- sw.js: cache offline.
- ícones PNG e SVG.
- melhorias, moedas, pets, mundos, missões, recompensa diária, renascimentos e salvamento local.

COMO FAZER PELO CELULAR (sem PC)
ETAPA 1 — publicar o site pelo celular
1. Baixe e extraia o ZIP usando o gerenciador de arquivos do Android.
2. No navegador, abra https://github.com e crie uma conta ou entre.
3. Crie um repositório público com um nome como million-clicks-premium.
4. Use Add file > Upload files para enviar os arquivos que estão na pasta do projeto. Envie index.html, manifest.webmanifest, sw.js, icon.svg, icon-192.png e icon-512.png. Se preferir, envie os arquivos um por um.
5. Abra Settings > Pages. Em Build and deployment escolha Deploy from a branch, branch main, folder /(root), e salve.
6. Aguarde a publicação e abra o endereço HTTPS mostrado pelo GitHub Pages. Teste o jogo.

ETAPA 2 — criar o APK
1. No celular, abra https://www.pwabuilder.com
2. Cole o endereço HTTPS do seu GitHub Pages e inicie a análise.
3. Se o site for reconhecido como PWA, escolha Package for stores / Android. Siga as instruções apresentadas pelo serviço para gerar o pacote Android. As opções e exigências podem mudar.
4. Se o serviço exigir assinatura, configuração extra ou conta de desenvolvedor, siga as instruções oficiais. Guarde a chave de assinatura com segurança; nunca a envie para terceiros.
5. Baixe o APK gerado, abra-o no Android e, se o sistema pedir, permita a instalação para esse navegador/gerenciador de arquivos.

IMPORTANTE
- Não consigo garantir que o APK seja gerado sem ajustes: os serviços mudam e podem pedir validações adicionais.
- Para publicar na Google Play, há requisitos adicionais de conta e política; instalar diretamente por APK é diferente de publicar na loja.
- O progresso é salvo no armazenamento local do navegador/app. Desinstalar, limpar dados ou mudar de aparelho pode apagar o progresso. Ainda não há sincronização em nuvem.
- O jogo foi preparado para funcionar offline depois do primeiro carregamento, mas a primeira publicação e instalação exigem internet.
- Para ícones PNG, este pacote contém ícones gerados para o app.
- Não compartilhe senha do GitHub nem chaves de assinatura.

SE ALGO NÃO FUNCIONAR
- Se o GitHub Pages mostrar 404, confirme que index.html está na raiz do repositório e que Pages está apontando para main / root.
- Se o jogo não instalar offline, abra primeiro o link publicado com internet e recarregue uma vez.
- Se o PWABuilder disser que faltam ícones, confirme que os dois PNG estão enviados.
